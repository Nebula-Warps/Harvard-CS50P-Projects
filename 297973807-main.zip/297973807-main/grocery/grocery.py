shopping_list = {}

while True:
    try:
        items = input().upper().strip()
        if items in shopping_list:

            shopping_list[items] += 1
        else:
            shopping_list[items] = 1

    except EOFError:
        break
result = sorted(shopping_list)
for n in result:
    print(f"{shopping_list[n]} {n}")


