import random


while True:
    try:
        n = int(input("Level: "))
        if n > 0:
            break
    except ValueError:
        pass

computer = random.randint(1, n)

while True:
    try:
        user = int(input("Guess: "))
        if user < 0:
            continue
        elif user < computer:
            print("Too small!")
        elif user > computer:
            print("Too large!")
        else:
            print("Just right")
            break

    except ValueError:
        pass


