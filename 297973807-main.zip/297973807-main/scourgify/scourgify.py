import sys
import csv

if len(sys.argv) < 3:
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 3:
    sys.exit("Too many command-line arguments")


if not sys.argv[1].endswith(".csv") or not sys.argv[2].endswith(".csv"):
    sys.exit("Not a Python file")

filename1 = sys.argv[1]
filename2 = sys.argv[2]
try:
    with open(filename1) as file:
        reader = csv.DictReader(file)
        with open(filename2, "w") as after:
            fieldnames = ["first", "last", "house"]
            writer = csv.DictWriter(after, fieldnames=fieldnames)
            writer.writeheader()

            for row in reader:
                name = row["name"]
                house = row["house"]

                last, first = name.split(", ")
                writer.writerow({"first": first, "last": last, "house": house})

except FileNotFoundError:
    sys.exit(f"Could not read {filename1}")
