def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    if len(s) < 2 or len(s) > 6:
        return False
    else:
        if not s.isalnum():
            return False
        if not (s[0].isalpha() and s[1].isalpha()):
            return False
        for n in range(len(s)):
            if s[n].isdigit():
                if s[n] == "0":
                    return False
                if not s[n:].isdigit():
                    return False
                break
        return True

if __name__ == "__main__":
    main()
