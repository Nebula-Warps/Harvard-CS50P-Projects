from plates import is_valid

def test_is_valid():
    assert is_valid("CS50") == True
    assert is_valid("ECTO88") == True
    assert is_valid("H") == False
    assert is_valid("NRVOUS") == True
    assert is_valid("PI3.14") == False
