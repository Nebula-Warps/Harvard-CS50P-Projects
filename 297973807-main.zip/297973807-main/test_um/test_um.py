from um import count


def count():
    assert count("Hello um my name is um") == 2
