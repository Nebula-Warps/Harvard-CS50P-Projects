import re


def main():
    print(convert(input("Hours: ")))


def convert(s):
    time = re.search(r"^([1-9]|1[0-2])(?::([0-5][0-9]))? (AM|PM) to ([1-9]|1[0-2])(?::([0-5][0-9]))? (AM|PM)$", s)
    if not time:
        raise ValueError("Invaild time format")
    h1, m1, p1, h2, m2, p2 = time.groups()
    start = to_24(int(h1), int(m1) if m1 else 0, p1)
    end = to_24(int(h2), int(m2) if m2 else 0, p2)
    return f"{start} to {end}"

def to_24(hour, minute, period):
    if period == "AM":
        if hour == 12:
            hour = 0
    else:
        if hour != 12:
            hour += 12
    return f"{hour:02d}:{minute:02d}"

if __name__ == "__main__":
    main()
