import convert from working

def convert():
    assert convert("2 AM to 9 PM") == "02:00 to 21:00"
