import pytest
import validate from numb3rs


def validate():
    assert validate("275.200.222.2") == "False"
    assert validate("255.200.100.2") == "True"
    assert validate("300.200.222.2") == "False"
