import emoji
output = input("Input: ")
print(emoji.emojize(output, language="alias"))
