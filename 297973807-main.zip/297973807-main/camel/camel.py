name = input("camelCase: ")
snake = ""
for n in name:
    if n.isupper():
        snake += "_" + n.lower()
    else:
        snake += n
print(f"snake_case: {snake}")

