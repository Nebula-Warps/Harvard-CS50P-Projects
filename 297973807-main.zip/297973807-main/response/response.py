import re

def main():
    email = input("What's your email? ")
    if validate(email):
        print("Valid")
    else:
        print("Invalid")

def validate(s):
    pattern = r"^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
    if re.search(pattern, s):
        return True
    return False

if __name__ == "__main__":
    main()
