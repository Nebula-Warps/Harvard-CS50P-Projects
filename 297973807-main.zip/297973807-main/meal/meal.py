def main():
    result = convert(input("What time is it? "))
    if 7.0 <= result <= 8.0:
        print("breakfast time")
    elif 12.0 <= result <= 13.0:
        print("lucnh time")
    elif 18.0 <= result <= 19.0:
        print("dinner time")
    else:
        return

def convert(time):
    hours, minute = time.split(":")
    hours = float(hours)
    minute = float(minute)

    return hours + (minute / 60.0)


if __name__ == "__main__":
    main()
