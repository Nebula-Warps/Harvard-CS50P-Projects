from bank import value

def test_greeting():
    assert value("Hello") == "0$"
    assert value("hi") == "20$"
    assert value("Whatup") == "100$"
    assert value("Yo") == "100$"
