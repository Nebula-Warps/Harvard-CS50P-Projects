import requests
import sys

if len(sys.argv) != 2:
    sys.exit("Missing Command-line argument")

try:
    convert = float(sys.argv[1])
except ValueError:
    sys.exit("Command-line argument is not a number")

api_key = "33bc52bdc705c43953e84aa2bad94c8e788340f549ec6716a6fa49a1423a530d"

try:
    response = requests.get(f"https://rest.coincap.io/v3/assets/bitcoin?apiKey={api_key}")
    response.raise_for_status()
except requests.RequestException:
    sys.exit("Request failed")

data = response.json()
price = float(data["data"]["priceUsd"])

n = convert * price
print(f"${n:,.4f}")
