def convert(emoji):
    return emoji.replace(":)", "🙂").replace(":(", "🙁")
def main():
    change = input("How are you feeling? ")
    print(convert(change))
main()
