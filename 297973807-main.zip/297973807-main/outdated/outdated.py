months = {
    "January": 1,
    "February": 2,
    "March": 3,
    "April": 4,
    "May": 5,
    "June": 6,
    "July": 7,
    "August": 8,
    "September": 9,
    "October": 10,
    "November": 11,
    "December": 12
}

while True:
    date = input("Data: ").strip()

    if "/" in date:

        month, day, year = date.split("/")

        month = int(month)
        day = int(day)
        year = int(year)

    else:
        date = date.replace(",", "")

        month_name, day, year = date.split(" ")

        month = months[month_name.title()]
        day = int(day)
        year = int(year)
    if 1 <= month <= 12 or 1 <= day <= 31:
        break

print(f"{year:04d}-{month:02d}-{day:02d}")
