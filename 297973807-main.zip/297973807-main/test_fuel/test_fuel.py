from fuel import convert
from fuel import gauge

def test_convert():
    assert convert("1/2") == 50
def test_gauge():
    assert gauge(0) == "E"
    assert gauge(100) == "F"
