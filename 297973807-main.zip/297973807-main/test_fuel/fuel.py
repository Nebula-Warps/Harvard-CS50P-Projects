def main():
    while True:
        try:
            fraction = input("Fraction: ")
            percentage = convert(fraction)
            print(gauge(percentage))
            break
        except ValueError:
            pass
        except ZeroDivisionError:
            pass

def convert(fraction):
    x, y = fraction.split("/")

    x = int(x)
    y = int(y)

    if x > y or y == 0:
        raise ValueError
    return round((x / y) * 100)

def gauge(percentage):

    if percentage <= 1:
        return "E"
    elif percentage >= 99:
        return "F"
    else:
        return f"{percentage}%"


if __name__ == "__main__":
    main()

