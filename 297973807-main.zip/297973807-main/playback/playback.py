story = input("A...Long...Long...Time...Ago...")
print(story.replace(" ", "..."))
