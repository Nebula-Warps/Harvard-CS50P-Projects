from datetime import date
from num2words import num2words
import sys

def main():
    try:
        print(calculate(input("Date  of birth: ")))
    except ValueError:
        sys.exit("Invalid Date")

def calculate(bd):
    today = date.today()

    birthday = date.fromisoformat(bd)
    difference = today - birthday
    minutes = difference.days * 24 * 60
    words = num2words(minutes).replace(" and", "").capitalize()
    return f"{words} minutes"



if __name__ == "__main__":
    main()
