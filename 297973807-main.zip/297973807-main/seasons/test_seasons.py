from seasons import calculate

def test_calculate():
    assert calculate("1999-01-07") == "Fourteen million, five hundred eighty-four thous, three hundred twenty minutes"
