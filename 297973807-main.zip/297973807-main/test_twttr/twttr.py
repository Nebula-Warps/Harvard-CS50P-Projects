def main():
    word = input("Input: ")
    print(f"Output: {shorten(word)}")

def shorten(word):
    names = ""
    for n in word:
        if n not in "AEIOUaeiou":
            names += n
    return names


if __name__ == "__main__":
    main()
