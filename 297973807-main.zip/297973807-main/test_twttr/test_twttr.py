from twttr import shorten

def test_shorten():
    assert shorten("Twitter") == "Twttr"
    assert shorten("APPle") == "PPl"
    assert shorten("AEIOU") == ""
    assert shorten("aeiou") == ""
    assert shorten("CS50") == "CS50"
