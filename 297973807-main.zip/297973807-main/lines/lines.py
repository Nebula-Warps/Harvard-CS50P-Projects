import sys

count = 0

if len(sys.argv) < 2:
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 2:
    sys.exit("Too many command-line arguments")


if not sys.argv[1].endswith(".py"):
    sys.exit("Not a Python file")


filename = sys.argv[1]
try:
    with open(filename) as file:
        lines = file.readlines()

except FileNotFoundError:
    sys.exit("File does not exist")

for line in lines:
    if not line.strip().startswith("#") and line.strip() != "":
        count += 1

print(count)
